package com.example.bamboostore

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
