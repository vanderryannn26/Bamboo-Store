import 'package:final_project/screens/admin/adminHomeScreen.dart';
import 'package:final_project/screens/customer/homeScreen.dart';
import 'package:final_project/screens/registerScreen.dart';
import 'package:flutter/material.dart';

class LoginScreen extends StatelessWidget {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  bool validAdmin = false;
  bool validEntry = false;
  String e = 'dwdwdw';
  String p = 'werwer';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.green.shade100, Colors.green.shade400],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),

        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'Banboo Store',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 32.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),

                const SizedBox(height: 16.0),
                TextField(
                  controller: emailController,
                  decoration: InputDecoration(
                    labelText: 'Email',
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                ),

                const SizedBox(height: 16.0),
                TextField(
                  controller: passwordController,
                  decoration: InputDecoration(
                    labelText: 'Password',
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                  obscureText: true,
                ),

                const SizedBox(height: 24.0),
                ElevatedButton(
                  onPressed: () {
                    if(emailController.text.isEmpty || passwordController.text.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Both fields can\'t be empty.'))
                      );
                    } else {
                      if(emailController.text.compareTo('admin') == 0 || passwordController.text.compareTo('admin') == 0) validAdmin = true;
                      if(emailController.text.compareTo(e) == 0 && passwordController.text.compareTo(p) == 0) validEntry = true;
                      if(validAdmin == false && validEntry == false) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Invalid credentials.'))
                        );
                      }
                    }

                    if(validAdmin) {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => AdminHomeScreen()),
                      );
                    }

                    if(validEntry) {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => HomeScreen()),
                      );
                    }
                  },

                  child: const Text('Login'),
                ),

                TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => RegisterScreen())
                    );
                  }, 

                  child: const Text('No account? Register here!')
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
