import 'package:final_project/screens/loginScreen.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(BanbooStoreApp());
}

class BanbooStoreApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Banboo Store',
      theme: ThemeData(
        primaryColor: Colors.red,
        colorScheme: ColorScheme.light(
          primary: Colors.red,
          secondary: Colors.red,
        ),

        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.red, // Fixed
            foregroundColor: Colors.white, // Fixed
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0)),
          ),
        ),
      ),

      home: LoginScreen(),
    );
  }
}
