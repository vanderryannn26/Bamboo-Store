// ignore_for_file: depend_on_referenced_packages

import 'package:final_project/components/imageCarousel.dart';
import 'package:final_project/components/listItem.dart';
import 'package:final_project/screens/admin/adminProfileScreen.dart';
import 'package:flutter/material.dart';

class AdminHomeScreen extends StatelessWidget {
  var stock = 3; // Stock

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Banboo Store'),
        backgroundColor: Colors.green,
        actions: [
          IconButton(
            icon: const Icon(Icons.person),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AdminProfileScreen()),
              );
            },
          ),
        ],
      ),

      body: Column(
        children: [
          ImageCarousel(),
          Expanded(
            child: ListView.builder(
              itemCount: stock,
              itemBuilder: (context, index) {return BanbooListItem();},
            ),
          ),
        ],
      ),

      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.green,
        onPressed: () {
          // Navigator.push(
          //   context,
          //   MaterialPageRoute(builder: (context) => RegisterScreen()),
          // );
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
