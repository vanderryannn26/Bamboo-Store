import 'package:flutter/material.dart';

class AdminProfileScreen extends StatelessWidget {
  const AdminProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        backgroundColor: Colors.green,
      ),

      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: Column(
            children: [
              const SizedBox(height: 36.0),
              const CircleAvatar(
                radius: 75.0,
                backgroundColor: Colors.green,
                child: Icon(
                  Icons.person,
                  size: 100.0,
                  color: Colors.white,
                ),
              ),

              const SizedBox(height: 36.0),
              const Text(
                'Admin',
                style: TextStyle(fontSize: 36.0, fontWeight: FontWeight.bold),
              ),

              const SizedBox(height: 36.0),
              ElevatedButton(
                onPressed: () {
                  
                },

                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                child: const Text('Add Item'),
              ),

              const SizedBox(height: 36.0),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.pop(context);
                },

                style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                child: const Text('Logout'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
