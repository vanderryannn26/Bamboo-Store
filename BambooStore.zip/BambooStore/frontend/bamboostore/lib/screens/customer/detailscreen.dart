import 'package:flutter/material.dart';

class ProductDetailsScreen extends StatelessWidget {
  const ProductDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Product Details'),
        backgroundColor: Colors.green,
      ),

      body: Column(
        children: [
          Image.network('https://via.placeholder.com/400'),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Banboo Name',
                  style: TextStyle(
                    fontSize: 24.0, 
                    fontWeight: FontWeight.bold
                  ),
                ),

                const SizedBox(height: 8.0),
                const Text('Price: \$100'),
                const SizedBox(height: 16.0),
                ElevatedButton(
                  onPressed: () {
                    // Add to cart logic
                  },

                  child: const Text('Buy Now'),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
