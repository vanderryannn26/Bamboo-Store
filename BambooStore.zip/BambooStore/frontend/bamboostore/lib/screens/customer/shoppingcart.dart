// ignore_for_file: use_key_in_widget_constructors

import 'package:flutter/material.dart';

class ShoppingCartScreen extends StatelessWidget {
  final List<Map<String, dynamic>> cartItems = [
    {'name': 'Banboo A', 'price': 100.0, 'quantity': 2},
    {'name': 'Banboo B', 'price': 150.0, 'quantity': 1},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Shopping Cart'),
        backgroundColor: Colors.green,
      ),

      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: cartItems.length,
              itemBuilder: (context, index) {
                final item = cartItems[index];

                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                  child: ListTile(
                    title: Text(item['name']),
                    subtitle: Text('Price: \$${item['price']} x ${item['quantity']}'),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete, color: Colors.red),
                      onPressed: () {
                        // Handle item removal
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text('${item['name']} has been removed from the shopping cart.'))
                        );
                      },
                    ),
                  ),
                );
              },
            ),
          ),

          // Padding(
          //   padding: const EdgeInsets.all(16.0),
          //   child: Row(
          //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //     children: [
          //       Text(
          //         'Total: \$${total.toStringAsFixed(2)}',
          //         style: const TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
          //       ),

          //       ElevatedButton(
          //         onPressed: () {
          //           // Handle checkout
          //         },

          //         child: const Text('Checkout'),
          //       ),
          //     ],
          //   ),
          // ),
        ],
      ),
    );
  }
}
