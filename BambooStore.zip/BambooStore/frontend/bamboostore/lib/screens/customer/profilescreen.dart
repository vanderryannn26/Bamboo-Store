// ignore_for_file: must_be_immutable, prefer_const_constructors

import 'package:flutter/material.dart';

// ignore: use_key_in_widget_constructors
class ProfileScreen extends StatelessWidget {
  var username = 'Username';
  var email = 'user@example.com';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        backgroundColor: Colors.green,
      ),

      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: Column(
            children: [
              const SizedBox(height: 36.0),
              const CircleAvatar(
                radius: 75.0,
                backgroundColor: Colors.green,
                child: Icon(
                  Icons.person,
                  size: 100.0,
                  color: Colors.white,
                ),
              ),

              const SizedBox(height: 36.0),
              Text(
                username,
                style: TextStyle(fontSize: 36.0, fontWeight: FontWeight.bold),
              ),

              const SizedBox(height: 8.0),
              Text(
                email,
                style: const TextStyle(fontSize: 18.0, color: Colors.grey),
              ),

              const SizedBox(height: 36.0),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                  Navigator.pop(context);
                },

                style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                child: const Text('Logout'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
