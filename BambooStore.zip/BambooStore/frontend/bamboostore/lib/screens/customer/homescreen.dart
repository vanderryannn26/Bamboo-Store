// ignore: depend_on_referenced_packages
// ignore_for_file: depend_on_referenced_packages, duplicate_ignore, must_be_immutable, non_constant_identifier_names

import 'package:bamboostore/components/listitem.dart';
import 'package:final_project/components/imageCarousel.dart';
import 'package:final_project/components/listItem.dart';
import 'package:final_project/screens/customer/profileScreen.dart';
import 'package:final_project/screens/customer/shoppingCart.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  var stock = 3;

  HomeScreen({super.key}); // Stock

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Banboo Store'),
        backgroundColor: Colors.green,
        actions: [
          IconButton(
            icon: const Icon(Icons.person),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProfileScreen()),
              );
            },
          ),
        ],
      ),

      body: Column(
        children: [
          ImageCarousel(),
          Expanded(
            child: ListView.builder(
              itemCount: stock,
              itemBuilder: (context, index) {return BanbooListItem();},
            ),
          ),
        ],
      ),

      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.green,
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => ShoppingCartScreen()),
          );
        },
        child: const Icon(Icons.shopping_cart),
      ),
    );
  }
}

ImageCarousel() {
}

ShoppingCartScreen() {
}
