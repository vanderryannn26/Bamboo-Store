// ignore_for_file: use_key_in_widget_constructors

import 'package:flutter/material.dart';

// ignore: must_be_immutable
class RegisterScreen extends StatelessWidget {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  bool validAccount = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Register'),
        backgroundColor: Colors.green,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(
                labelText: 'Username',
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 16.0),
            TextField(
              controller: emailController,
              decoration: const InputDecoration(
                labelText: 'Email',
                border: OutlineInputBorder(),
              ),
            ),

            const SizedBox(height: 16.0),
            TextField(
              controller: passwordController,
              decoration: const InputDecoration(
                labelText: 'Password',
                border: OutlineInputBorder(),
              ),

              obscureText: true,
            ),

            const SizedBox(height: 24.0),
            ElevatedButton(
              onPressed: () {
                // Handle registration logic
                if(nameController.text.isEmpty || emailController.text.isEmpty || passwordController.text.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('All the fields can\'t be empty.'))
                  );
                } else {
                  if(!emailController.text.contains('@') || !emailController.text.contains('.')) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Email must contain both "@" and ".".'))
                    );
                  }

                  if(passwordController.text.length < 8) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Password must contain at least 8 characters.'))
                    );
                  }

                  if(emailController.text.contains('@') && emailController.text.contains('.') && passwordController.text.length >= 8) {
                    validAccount = true;
                  }
                }

                if(validAccount) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Your account has been successfully registered.'))
                  );

                  Navigator.pop(context);
                }
              },

              child: const Text('Register'),
            ),
          ],
        ),
      ),
    );
  }
}
