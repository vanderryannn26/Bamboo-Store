import 'package:final_project/screens/customer/detailScreen.dart';
import 'package:flutter/material.dart';

class BanbooListItem extends StatelessWidget {
  String banbooName = 'Banboo Name';
  var price = 1000;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: ListTile(
        leading: Image.network('https://via.placeholder.com/50'),
        title: Text(banbooName),
        subtitle: Text('Price: \$${price}'),
        trailing: const Icon(Icons.arrow_forward, color: Colors.green),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => ProductDetailsScreen()),
          );
        },
      ),
    );
  }
}
