class Banboo {
  String banbooID;
  String banbooName;
  double banbooPrice;
  String? banbooDesc;
  String elementID;
  int banbooLevel;

  // ignore: non_constant_identifier_names
  Banboo({required this.banbooID, required this.banbooName, required this.banbooPrice, required this.elementID, required this.banbooLevel, this.banbooDesc, required String BanbooID});

  factory Banboo.fromJson(Map<String, dynamic> json) => Banboo(
    BanbooID: json[].toString(), banbooID: '', banbooLevel: null, banbooName: '', banbooPrice: null, elementID: '';
    BanbooName: json[].toString();
    BanbooPrice: json[] as double;
    BanbooDesc: json[].toString();
    ElementID: json[].toString();
    BanbooLevel: json[] as int;
  );
}