import 'dart:convert';
import 'package:final_project/models/banboo.dart';
import 'package:http/http.dart' as http;

const String urlpath = "http://10.0.2.2:3000";

Future<List<Banboo>> fetchBanboo() async {
  List<Banboo> banbooList = [];
  String url = '$urlpath/banboos';
  var response = await http.get(Uri.parse(url));
  var result = jsonDecode(response.body);

  for (var element in result) {
    Banboo banboo = Banboo.fromJson(element);

    banbooList.add(banboo);
  }

  return banbooList;
}